//
//  MyFirstApp.swift
//  MyFirst
//
//  Created by Swift-Beginners
//

import SwiftUI

@main
struct MyFirstApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
