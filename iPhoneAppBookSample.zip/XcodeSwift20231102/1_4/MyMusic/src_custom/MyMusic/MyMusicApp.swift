//
//  MyMusicApp.swift
//  MyMusic
//
//  Created by Swift-Beginners.
//

import SwiftUI

@main
struct MyMusicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
